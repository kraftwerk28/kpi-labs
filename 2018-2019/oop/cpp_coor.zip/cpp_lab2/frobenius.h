//
// Created by kraftwerk28 on 12.12.18.
//

#ifndef OOP_LAB_2_FROBENIUS_H
#define OOP_LAB_2_FROBENIUS_H

#include "matrix.h"

matrix frobenius()
{
  return matrix{};
}

#endif //OOP_LAB_2_FROBENIUS_H
