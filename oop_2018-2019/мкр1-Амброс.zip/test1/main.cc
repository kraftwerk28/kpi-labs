#include <iostream>
#include "graph_solver.h"

int main()
{
    std::cout << "Hello, World!" << std::endl;
    graph_solver *gs1 = new dfs_solver({
                                          {0, 1, 1, 0},
                                          {1, 0, 1, 1},
                                          {1, 1, 0, 0},
                                          {0, 1, 0, 0}
                                      });

    graph_solver *gs2 = new bfs_solver({
                                          {0, 1, 1, 0},
                                          {1, 0, 1, 1},
                                          {1, 1, 0, 0},
                                          {0, 1, 0, 0}
                                      });

    gs1->find(0);
    gs2->find(0);



    return 0;

}